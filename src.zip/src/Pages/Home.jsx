import React from "react";
import Sidebar from "../Components/Sidebar";
import Header from "../Components/Header";
import { Grid } from "@mui/material";

const Home = () => {
  return (
    <React.Fragment>
      <Header />
      
    </React.Fragment>
  );
};
export default Home;

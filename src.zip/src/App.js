import React from "react";
import "./App.css";
import RouterComponent from "./Router/RouterComponent";
function App() {
  return (
    <React.Fragment>
      <RouterComponent />
    </React.Fragment>
  );
}

export default App;
